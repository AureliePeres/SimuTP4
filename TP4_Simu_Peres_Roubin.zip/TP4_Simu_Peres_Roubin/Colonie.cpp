/** ------------------------------------------------------------------------ *
  * Colonie.cpp																 *
  *         																 *
  * -Impl�mente la classe Colonie											 *
  *         																 *
  * @author Peres Aur�lie													 *
  * @author Roubin Thibaut													 * 
  *         																 *  
* ------------------------------------------------------------------------ **/

#include "Colonie.hpp"

//constructeur

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Constructeur par d�faut													 *
  *   -Construction d'une population compos�e d'un lapin et d'une lapine     *  
  *    de 7 mois.															 * 
  *         																 *  
* ------------------------------------------------------------------------ **/
Colonie::Colonie():males_(),femelles_()
{
    males_.push_front(new Lapin(7));
	femelles_.push_front(new Lapine(7));
}

//destructeur

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Destructeur																 *
  *   -lib�re la m�moire.													 * 
  *                                						 					 *     
* ------------------------------------------------------------------------ **/
Colonie::~Colonie()
{
    std::list<Lapin *>::iterator 		it_male;
	std::list<Lapine *>::iterator 		it_femelle;

	for(it_male = males_.begin() ; it_male!=males_.end() ; it_male++)
	{
		delete (*it_male);
	}
    for(it_femelle = femelles_.begin() ; it_femelle!=femelles_.end();it_femelle++)
	{
		delete (*it_femelle);
	}
}

//get

/** ----------------------------------------------------------------------------------- *
  *         																 			* 
  * Retourne la taille de la colonie.										 			*
  *  -Ne marche pas s'il existe plusieurs instances de Colonie.			 			*
  *                                						 					 			* 
  * @return 		 	le nombre de naissance total moins le nombre de mort total		*  
  *         																 			*     
* ----------------------------------------------------------------------------------- **/
int Colonie::taille_colonie()
{
	return Lapin::get_nb_vie_()-Lapin::get_nb_mort_();
}

//m�thode

/** ------------------------------------------------------------------------------------------- *
  *         																 					* 
  * Fait vieillir et reproduire toute la population												*
  *  -Appelle vieillir() pour chaque lapin, puis retire ou ajoute des lapins en cons�quence	 	*
  *                                						 					 					* 
  * @return 		 	true si il reste des lapins, false sinon								*  
  *         																 					*     
* ------------------------------------------------------------------------------------------- **/
bool Colonie::coloniser()
{
	int			    				nb_tmp=0,nb_total=0;
	std::list<Lapin *>::iterator 	it_male;
	std::list<Lapine *>::iterator 	it_femelle;
	double							alea;
	bool            				vivant=true;

	//males
	it_male=males_.begin();
	while (it_male != males_.end())
    {
        if( (*it_male)->vieillir() == -1 )
        {
            delete (*it_male);
            males_.erase(it_male++);
        }
        else
        {
            it_male++;
        }
    }
	//femelles
	it_femelle=femelles_.begin();
	while (it_femelle != femelles_.end())
	{
		nb_tmp= (*it_femelle)->vieillir();
		if( nb_tmp  == -1 )
		{
		    delete (*it_femelle);
			femelles_.erase(it_femelle++);
		}
		else
        {
            it_femelle++;
        }
		if (nb_tmp > 0)
		{
		    nb_total+=nb_tmp;
		}
	}
	for(;nb_total > 0;nb_total--)
    {
        alea=(double)rand() / (double)RAND_MAX;
        if(alea < 0.5)
        {
            males_.push_front(new Lapin);
        }
        else
        {
            femelles_.push_front(new Lapine);
        }
    }
	if(femelles_.size()==0 && males_.size()==0)
    {
        vivant=false;
    }
    return vivant;
}
