/** ------------------------------------------------------------------------ *
  * Main.cpp																 *
  *         																 *
  * -Initialise la fonction de génération pseudo-aléatoire.					 *
  * -Prend en paramètre le nombre de mois de croissance (120 si non précisé) *
  *         																 *
  * @author Peres Aurélie													 *
  * @author Roubin Thibaut													 * 
  *         																 *  
* ------------------------------------------------------------------------ **/
#include <iostream>
#include <cstdlib>
#include "Lapine.hpp"
#include "Colonie.hpp"

double global_seed = 0x123234345456;//std::chrono::system_clock::now().time_since_epoch().count();
std::mt19937 global_alea (global_seed);

int main(int argc, char * argv[])
{
	int 			i=0;
	Colonie 		c;
	bool 			non_vide=true;
	int				nb_mois=120;
	
	if(argc >2)
	{
		std::cout<< "ERREUR : un seul paramètre attendu." << std::endl;
	}
	else if (argc == 2)
	{
		nb_mois=std::stoi(argv[1]);
	}
	while(non_vide && i<nb_mois)
	{
        non_vide=c.coloniser();
        i++;
        std::cout << "Mois numero " << i << ": " << std::endl;
        std::cout << "   Taille de la poulation 		:" << c.taille_colonie() << std::endl;
        std::cout << "   Nombre de naissance au total 	:" <<  Lapin::get_nb_vie_() << std::endl;
	}
	return 0;
}
