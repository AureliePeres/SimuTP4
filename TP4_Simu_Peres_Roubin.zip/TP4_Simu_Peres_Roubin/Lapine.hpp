/** ------------------------------------------------------------------------ *
  * Lapine.hpp																 *
  *         																 *
  * -Définit la classe Lapine, qui hérite de lapin.						 	 *
  *         																 *
  * @author Peres Aurélie													 *
  * @author Roubin Thibaut													 * 
  *         																 *  
* ------------------------------------------------------------------------ **/

#ifndef	_H_LAPINE_1_
#define	_H_LAPINE_1_

#include "Lapin.hpp"

/** ------------------------------------------------------------------------------- *
  * Classe Lapine															 		*
  *         																 		* 
  * nb_portee_       : nombre de portée prévu pour l'année					 		*
  * debut_gestation_ : compteur de temps allant de 0 à 12 pour simuler une année	*
  *         																 		* 
* ------------------------------------------------------------------------------- **/
class Lapine : public Lapin
{
protected:
	//attributs
	unsigned 		nb_portee_;
	unsigned 		debut_gestation_;  

public:
	//constructeurs
	Lapine			();
	Lapine(const Lapine& l2);
	Lapine			(unsigned age);

	//méthode
	int	vieillir();
};

#endif
