/** ------------------------------------------------------------------------ *
  * Colonie.hpp																 *
  *         																 *
  * -D�finit la classe Colonie											 	 *
  *         																 *
  * @author Peres Aur�lie													 *
  * @author Roubin Thibaut													 * 
  *         																 *  
* ------------------------------------------------------------------------ **/

#ifndef	_H_COLONIE_1_
#define	_H_COLONIE_1_


#include <list>
#include "Lapine.hpp"

/** ------------------------------------------------------------------------ *
  * Classe Colonie															 *
  *         																 * 
  * males_   	: liste contenant les lapins males							 *
  * femelles_ 	: liste contenant les lapins femelles						 *
  *         																 * 
* ------------------------------------------------------------------------ **/
class Colonie
{
protected:
	std::list <Lapin *>		males_;
	std::list <Lapine *>	femelles_;

public:
	//constructeur
	Colonie();

    //destructeur
    ~Colonie();
    
    //get
	int			taille_colonie();

	//m�thode
	bool 		coloniser();
};

#endif
