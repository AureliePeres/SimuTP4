var searchData=
[
  ['get_5fnb_5fmort_5f',['get_nb_mort_',['../classLapin.html#a259012a0481b7fc301ffe141671f73ec',1,'Lapin']]],
  ['get_5fnb_5fvie_5f',['get_nb_vie_',['../classLapin.html#aec077a3bb0b55b60effe4e72e1c3be58',1,'Lapin']]]
];
