/** ------------------------------------------------------------------------ *
  * Lapine.cpp																 *
  *         																 *
  * -Incrémente la classe Lapine.											 *
  *         																 *
  * @author Peres Aurélie													 *
  * @author Roubin Thibaut													 * 
  *         																 *  
* ------------------------------------------------------------------------ **/
#include "Lapine.hpp"

//variables globales
extern std::mt19937 global_alea;

//constructeur

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Constructeur par défaut													 *
  *   -Construction d'un lapereau femelle				 					 *
  *   -Incrémente nb_vie_ (en appellant le constructeur de Lapin)			 * 
  *         																 *   
* ------------------------------------------------------------------------ **/
Lapine::Lapine():Lapin()
{
	nb_portee_=0;
	debut_gestation_=0;
}

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Constructeur par copie													 *
  *                                						 					 * 
  * @param 		l2 		lapine à copier    									 *  
  *         																 *   
* ------------------------------------------------------------------------ **/
Lapine::Lapine(const Lapine& l2):Lapin(l2)
{
	nb_portee_=l2.nb_portee_;
	debut_gestation_=l2.debut_gestation_;
}


/** ------------------------------------------------------------------------ *
  *         																 * 
  * Constructeur avec un age défini											 *
  *   -Construction d'une lapine adulte avec un age défini.					 * 
  *                                						 					 * 
  * @param 		age 	age de la lapine à créer   							 *  
  *         																 *     
* ------------------------------------------------------------------------ **/
Lapine::Lapine(unsigned age):Lapin(age)
{
	nb_portee_=0;
	debut_gestation_=0;
}

//méthode

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Fait vieillir la lapine													 *
  *   -évalue si le lapin devient mature	(en appellant Lapin::vieillir())	 *
  *   -évalue si le lapin meurt (en appellant Lapin::vieillir())				 * 
  *   -évalue le nombre de portée de l'année (si nécessaire)					 * 
  *   -évalue la taille de la portée (si nécessaire)							 * 
  *                                						 					 * 
  * @return 			-1 si le lapin meurt, taille de la portée sinon		 *  
  *         																 *     
* ------------------------------------------------------------------------ **/
int Lapine::vieillir()
{
	int				nb = Lapin::vieillir();
    float           local_alea=(float)global_alea() / (float)global_alea.max();
    
	if(nb == 0)
	{
		if(mature_ == true && debut_gestation_ ==0)
		{
			if(local_alea < 0.10)
				nb_portee_=4;
			else if (local_alea < 0.3)
				nb_portee_=5;
			else if (local_alea < 0.7)
				nb_portee_=6;
			else if (local_alea < 0.9)
				nb_portee_=7;
			else
				nb_portee_=8;
		}
		else if (nb_portee_ >0)
		{
			local_alea= rand()%4;
			nb=3+local_alea;
			nb_portee_ --;

		}
		debut_gestation_= (debut_gestation_ + 1) % 12;
	}
	return nb;
}
