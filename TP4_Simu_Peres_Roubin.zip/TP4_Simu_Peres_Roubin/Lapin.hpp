/** ------------------------------------------------------------------------ *
  * Lapin.hpp																 *
  *         																 *
  * -D�finit la classe Lapin.											 	 *
  *         																 *
  * @author Peres Aur�lie													 *
  * @author Roubin Thibaut													 * 
  *         																 *  
* ------------------------------------------------------------------------ **/

#ifndef	_H_LAPIN_1_
#define	_H_LAPIN_1_

#include <random>

/** ------------------------------------------------------------------------ *
  * Classe Lapin															 *
  *         																 * 
  * nb_vie_  : nombre de naissance de lapin.								 	 *
  * nb_mort_ : nombre de mort de lapin.										 *
  * age_     : age du lapin en mois											 *  
  * mature_  : d�finit si le lapin est mature ou non.							 * 
  *         																 * 
* ------------------------------------------------------------------------ **/
class Lapin
{
protected:

	//attributs de classe
	static int 		nb_vie_;
	static int		nb_mort_;

	//autres attributs
	unsigned int	age_;
	bool			mature_;

public:

	//constructeurs
	Lapin			();
	Lapin           (const Lapin& l2);
	Lapin			(unsigned age);

	//destructeur
	~Lapin			();

	//gets
	static int				get_nb_vie_();
	static int				get_nb_mort_();

	//m�thode
	int	vieillir();
};

#endif

