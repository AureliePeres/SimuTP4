/** ------------------------------------------------------------------------ *
  * Lapin.cpp																 *
  *         																 *
  * -Incrémente la classe Lapin.											 *
  *         																 *
  * @author Peres Aurélie													 *
  * @author Roubin Thibaut													 * 
  *         																 *  
* ------------------------------------------------------------------------ **/

#include "Lapin.hpp"

//attributs de classe

int 				Lapin::nb_vie_=0;
int 				Lapin::nb_mort_=0;

//variables globales
extern std::mt19937 global_alea;

//consts
const float		    taux_mort_adulte = pow(0.5,(float)1/12);
const float 		taux_mort_jeune = pow(0.2,(float)1/12);
const float	    	taux_mort_11 = pow(0.4,(float)1/12);
const float		    taux_mort_12 = pow(0.3,(float)1/12);
const float 		taux_mort_13 = pow(0.2,(float)1/12);
const float	    	taux_mort_14 = pow(0.1,(float)1/12);


//constructeurs

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Constructeur par défaut													 *
  *   -Construction d'un lapereau						 					 *
  *   -Incrémente nb_vie_								 					 * 
  *         																 *   
* ------------------------------------------------------------------------ **/
Lapin::Lapin()
{
	nb_vie_++;
	age_=0;
	mature_=false;
}

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Constructeur par copie													 *
  *                                						 					 * 
  * @param 		l2 		lapin à copier    									 *  
  *         																 *   
* ------------------------------------------------------------------------ **/
Lapin::Lapin(const Lapin& l2)
{
    age_=l2.age_;
	mature_=l2.mature_;
}

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Constructeur avec un age défini											 *
  *   -Construction d'un lapin adulte avec un age défini.					 * 
  *                                						 					 * 
  * @param 		age 	age du lapin à créer   								 *  
  *         																 *     
* ------------------------------------------------------------------------ **/
Lapin::Lapin(unsigned age)
{
	nb_vie_++;

	age_=age;
	mature_=true;
}

//destructeurs

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Destructeur																 *
  *   -Incrémente nb_mort_													 * 
  *                                						 					 *     
* ------------------------------------------------------------------------ **/
Lapin::~Lapin()
{
	nb_mort_++;
}

//gets

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Accesseur de l'attribut de classe nb_vie_								 *
  *                                						 					 * 
  * @return 		 	l'attribut de classe nb_vie_						 *  
  *         																 *     
* ------------------------------------------------------------------------ **/
int	Lapin::get_nb_vie_()
{
	return nb_vie_;
}

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Accesseur de l'attribut de classe nb_mort_								 *
  *                                						 					 * 
  * @return 		 	l'attribut de classe nb_mort_						 *  
  *         																 *     
* ------------------------------------------------------------------------ **/
int	Lapin::get_nb_mort_()
{
	return nb_mort_;
}

//méthode

/** ------------------------------------------------------------------------ *
  *         																 * 
  * Fait vieillir le lapin													 *
  *   -évalue si le lapin devient mature										 *
  *   -évalue si le lapin meurt												 * 
  *                                						 					 * 
  * @return 			-1 si le lapin meurt, 0 sinon						 *  
  *         																 *     
* ------------------------------------------------------------------------ **/
int Lapin::vieillir()
{
	int				mort=0;
    float           local_alea=(float)global_alea() / (float)global_alea.max();

	age_++;
	
	//maturité
	if(mature_==false && age_ >=5 )
	{
		if(age_==5 && local_alea <0.25)
		{
			mature_=true;
		}
		else if(age_==6 && local_alea <0.5)
		{
			mature_=true;
		}
		else if(age_==7 && local_alea <0.75)
		{
			mature_=true;
		}
		else
		{
			mature_=true;
		}
	}

	//mort
	local_alea=(float)global_alea() / (float)global_alea.max();
	if( (mature_ == false && local_alea > taux_mort_jeune ) || local_alea > taux_mort_adulte)
	{
		mort=-1;
	}
	else if ( ( age_ >= 180 ) || ( age_ >= 168 && local_alea > taux_mort_14 ) || ( age_ >= 156 && local_alea > taux_mort_13 ) || ( age_ >= 144 && local_alea > taux_mort_12 ) || ( age_ >= 132 && local_alea > taux_mort_11 ) )
	{
		mort = -1;
	}
	return mort;
}

